package com.movtalent.app.view;

/**
 * @author huangyong
 * createTime 2019-09-15
 */
public interface OnSearchListener {
    void doSearch(String keyWord);
}
