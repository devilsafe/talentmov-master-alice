package com.movtalent.app.model;

/**
 * @author huangyong
 * createTime 2019-09-15
 */
public class FooterView {
    private String catName;

    public FooterView(String catName) {
        this.catName = catName;
    }

    public String getCatName() {
        return catName;
    }
}
