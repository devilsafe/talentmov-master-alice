package com.movtalent.app.adapter.user;


/**
 * @author huangyong
 * createTime 2019-09-16
 */
public class SelfBodyView {


}