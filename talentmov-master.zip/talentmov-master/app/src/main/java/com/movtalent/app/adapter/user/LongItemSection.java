package com.movtalent.app.adapter.user;

/**
 * @author huangyong
 * createTime 2019-09-19
 */
public class LongItemSection {

}