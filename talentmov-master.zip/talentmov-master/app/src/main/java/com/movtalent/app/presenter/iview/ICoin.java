package com.movtalent.app.presenter.iview;

/**
 * @author huangyong
 * createTime 2019-09-20
 */
public interface ICoin extends IBase {
    void updateCoin(String coin);
}
