package com.movtalent.app.presenter.iview;


/**
 * @author huangyong
 * createTime 2019-09-14
 */
public interface IBase {
    void loadError();
    void loadEmpty();

}
